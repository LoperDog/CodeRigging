﻿using UnityEngine;
using System.Collections;

public class MeshHome : MonoBehaviour
{

    public Material mat;
    public Transform[] bones;
    // Use this for initialization
    void Start()
    {

        Mesh m = new Mesh();
        m.vertices = new Vector3[]
        {
            //new Vector3(0.0f,0.0f,0.0f),
            //new Vector3(-3.0f,6.0f,0.0f),
            //new Vector3(3.0f,6.0f,0.0f),
            //new Vector3(-4.0f,2.0f,0.0f),
            //new Vector3(-6.0f,3.0f,0.0f),
            //new Vector3(4.0f,2.0f,0.0f),
            //new Vector3(6.0f,3.0f,0.0f),
            //new Vector3(-3.0f,-6.0f,0.0f),
            //new Vector3(-6.0f,-6.0f,0.0f),
            //new Vector3(3.0f,-6.0f,0.0f),
            //new Vector3(6.0f,-6.0f,0.0f),

            new Vector3(-1.0f,10f,0.0f),    //1
            new Vector3(1.0f,10f,0.0f),     //2
            new Vector3(-1.0f,8f,0.0f),     //3
            new Vector3(1.0f,8f,0.0f),      //4
            new Vector3(0.0f,7f,0.0f),      //5
            new Vector3(-3.0f,7f,0.0f),     //6
            new Vector3(3.0f,7f,0.0f),      //7
            new Vector3(-4.0f,4.5f,0.0f),      //8
            new Vector3(-3.0f,4f,0.0f),      //9
            new Vector3(3.0f,4f,0.0f),      //10
            new Vector3(4.0f,4.5f,0.0f),      //11
            new Vector3(0.0f,3f,0.0f),      //12
            new Vector3(-2.0f,3f,0.0f),      //13
            new Vector3(2.0f,3f,0.0f),      //14
            new Vector3(0.0f,0.0f,0.0f),      //15
            new Vector3(-2.0f,0.0f,0.0f),      //16
            new Vector3(2.0f,0.0f,0.0f),      //17
            new Vector3(-2.5f,6.0f,0.0f),      //18
            new Vector3(2.5f,6.0f,0.0f)      //19

        };

        m.triangles = new int[] {
            // 머리 목.
            2, 0, 1,
            3, 2, 1,
            3, 4, 2,
            //가슴
            6,11,5,
            //왼팔
            17,7,5,
            17,8,7,
            //오른팔
            6,10,18,
            18,10,9,
            //하체
            12,13,14,
            12,14,15,
            14,13,16
        };
        m.bindposes = new Matrix4x4[]
        {
            bones[0].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[1].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[2].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[3].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[4].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[5].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[6].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[7].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[8].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[9].worldToLocalMatrix * transform.localToWorldMatrix,
            bones[10].worldToLocalMatrix * transform.localToWorldMatrix
        };

        m.boneWeights = new BoneWeight[]
        {
            // 머리 리깅
           new BoneWeight() { boneIndex0 = 0, weight0 = 1f },   //1
           new BoneWeight() { boneIndex0 = 0, weight0 = 1f },   //2
           new BoneWeight() { boneIndex0 = 0, weight0 = 1f },   //3
           new BoneWeight() { boneIndex0 = 0, weight0 = 1f },   //4
           new BoneWeight() { boneIndex0 = 1, weight0 = 1f },   //5

           new BoneWeight() { boneIndex0 = 3, weight0 = 1f },   //6
           new BoneWeight() { boneIndex0 = 2, weight0 = 1f },   //7
           new BoneWeight() { boneIndex0 = 6, weight0 = 1f },   //8
           new BoneWeight() { boneIndex0 = 6, weight0 = 1f },   //9
           new BoneWeight() { boneIndex0 = 5, weight0 = 1f },   //10
           new BoneWeight() { boneIndex0 = 5, weight0 = 1f },   //11
           new BoneWeight() { boneIndex0 = 4, weight0 = 1f },   //12
           new BoneWeight() { boneIndex0 = 4, weight0 = 1f },   //13
           new BoneWeight() { boneIndex0 = 4, weight0 = 1f },   //14
           new BoneWeight() { boneIndex0 = 4, weight0 = 1f },   //15
           new BoneWeight() { boneIndex0 = 8, weight0 = 1f },   //16
           new BoneWeight() { boneIndex0 = 7, weight0 = 1f },   //17
           new BoneWeight() { boneIndex0 = 3, weight0 = 1f },   //18
           new BoneWeight() { boneIndex0 = 2, weight0 = 1f },   //19
        };

        SkinnedMeshRenderer sar = GetComponent<SkinnedMeshRenderer>();
        sar.sharedMesh = m;
        sar.sharedMaterial = mat;
        sar.bones = bones;
        sar.rootBone = transform;
        sar.quality = SkinQuality.Bone1;
        //sar.quality = SkinQuality.Bone2;
    }

    // Update is called once per frame
    void Update()
    {

    }
}